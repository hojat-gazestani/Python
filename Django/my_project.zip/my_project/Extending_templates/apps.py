from django.apps import AppConfig


class ExtendingTemplatesConfig(AppConfig):
    name = 'Extending_templates'
