from django.apps import AppConfig


class TemplateviewPagesConfig(AppConfig):
    name = 'TemplateView_pages'
